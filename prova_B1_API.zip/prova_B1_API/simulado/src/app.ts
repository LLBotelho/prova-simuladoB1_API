// app.ts

import express from 'express';
import pacienteRoutes from './routes/pacienteRoutes';
import consultaRoutes from './routes/consultaRoutes';
import agendaRoutes from './routes/agendaRoutes';
import secretariaRoutes from './routes/secretariaRoutes';

const app = express();

app.use(express.json());

app.use('/api', pacienteRoutes);
app.use('/api', consultaRoutes);
app.use('/api', agendaRoutes);
app.use('/api', secretariaRoutes);

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});

