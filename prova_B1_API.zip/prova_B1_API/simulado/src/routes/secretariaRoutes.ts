// secretariaRoutes.ts

import { Router } from 'express';
import SecretariaController from '../controllers/secretariaController';

const router = Router();

router.post('/pacientes', SecretariaController.create);
router.get('/pacientes', SecretariaController.read);
router.put('/pacientes/:id', SecretariaController.update);
router.delete('/pacientes/:id', SecretariaController.delete);

export default router;
