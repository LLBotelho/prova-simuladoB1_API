// agendaRoutes.ts

import { Router } from 'express';
import AgendaController from '../controllers/agendaController';

const router = Router();

router.post('/pacientes', AgendaController.create);
router.get('/pacientes', AgendaController.read);
router.put('/pacientes/:id', AgendaController.update);
router.delete('/pacientes/:id', AgendaController.delete);

export default router;
