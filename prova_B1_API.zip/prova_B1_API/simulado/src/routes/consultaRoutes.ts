// consultaRoutes.ts

import { Router } from 'express';
import ConsultaController from '../controllers/consultaController';

const router = Router();

router.post('/pacientes', ConsultaController.create);
router.get('/pacientes', ConsultaController.read);
router.put('/pacientes/:id', ConsultaController.update);
router.delete('/pacientes/:id', ConsultaController.delete);

export default router;
