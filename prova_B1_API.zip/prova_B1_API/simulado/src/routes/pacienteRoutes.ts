// pacienteRoutes.ts

import { Router } from 'express';
import PacienteController from '../controllers/pacienteController';

const router = Router();

router.post('/pacientes', PacienteController.create);
router.get('/pacientes', PacienteController.read);
router.put('/pacientes/:id', PacienteController.update);
router.delete('/pacientes/:id', PacienteController.delete);

export default router;
